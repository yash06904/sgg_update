import torch.nn as nn
import torch.nn.parallel
from torch.autograd import Variable
from torch.nn import functional as F
from sgg_models.rel_model_base import RelModelBase
from lib.rel_assignments import rel_assignments
from lib.losses import node_losses, edge_losses #### YM ####
from lib.surgery import filter_dets
from config import NO_GRAD
import numpy as np

class RelModelStanford(RelModelBase):

    def __init__(self,
                 train_data,
                 hidden_dim=512,
                 mp_iter=3,
                 **kwargs):
        """
        Message Passing Model from Scene Graph Generation by Iterative Message Passing (https://arxiv.org/abs/1701.02426)
        :param classes: Object classes
        :param rel_classes: Relationship classes. None if were not using rel mode
        """
        super(RelModelStanford, self).__init__(train_data, **kwargs)

        print(self.mode, self.backbone, self.RELS_PER_IMG, self.use_bias, self.test_bias, self.require_overlap)

        self.hidden_dim = hidden_dim

        self.gd_rel_fc = nn.Linear(6*hidden_dim, self.num_rels)
        self.gd_obj_fc = nn.Linear(hidden_dim, self.num_classes)

        self.gd_obj_unary = nn.Linear(self.obj_dim, hidden_dim)
        self.gd_edge_unary = nn.Linear(self.obj_dim, hidden_dim)

        self.mp_iter = mp_iter
        
        self.pe1 = nn.Linear(3*hidden_dim,1)
        self.pe2 = nn.Linear(3*hidden_dim,1)
        self.pe3 = nn.Linear(3*hidden_dim,1)
        self.pe4 = nn.Linear(3*hidden_dim,1)

        self.pv1 = nn.Linear(hidden_dim,1)
        self.pv2 = nn.Linear(hidden_dim,1)
        self.pv3 = nn.Linear(hidden_dim,1)
        self.pv4 = nn.Linear(hidden_dim,1)

        self.we1 = nn.Linear(3*hidden_dim,3*hidden_dim)
        self.we2 = nn.Linear(3*hidden_dim,3*hidden_dim)
        self.we3 = nn.Linear(3*hidden_dim,3*hidden_dim)
        self.we4 = nn.Linear(3*hidden_dim,3*hidden_dim)

        self.wn1 = nn.Linear(hidden_dim,hidden_dim)
        self.wn2 = nn.Linear(hidden_dim,hidden_dim)
        self.wn3 = nn.Linear(hidden_dim,hidden_dim)
        self.wn4 = nn.Linear(hidden_dim,hidden_dim)

        self.merge_node =  nn.Linear(2*hidden_dim,hidden_dim)
        self.merge_edge =  nn.Linear(6*hidden_dim,6*hidden_dim)  

        #### YM ####
        self.ob_mat = torch.ones(151,151)
        self.rel_mat =1*torch.ones(151,151,51)

    
    def create_edge_adjacency(self,edges_in):
    
        num_edges = edges_in.size(0)
        r1 = edges_in[:,0].resize(num_edges,1)
        c1 = edges_in[:,0].resize(1,num_edges)
        z1 = (r1 == c1).nonzero()
    
        r2 = edges_in[:,0].resize(num_edges,1)
        c2 = edges_in[:,1].resize(1,num_edges)
        z2 = (r2 == c2).nonzero()
    
        r3 = edges_in[:,1].resize(num_edges,1)
        c3 = edges_in[:,0].resize(1,num_edges)
        z3 = (r3 == c3).nonzero()
    
        r4 = edges_in[:,1].resize(num_edges,1)
        c4 = edges_in[:,1].resize(1,num_edges)
        z4 = (r4 == c4).nonzero()
    
        zout = torch.cat([z1,z2,z3,z4],axis = 0)
    
        a_uniq = torch.unique(zout,dim=0)
    
        return a_uniq


    def create_deg_matrix(self,adj_in):
        colsum = torch.sum(adj_in,axis = 0)
        row_sum = torch.sum(adj_in,axis = 1)
        deg_vec = torch.zeros(adj_in.size(0))

        for i in range(colsum.size(0)):
            deg_vec[i] = colsum[i] + row_sum[i] 
        
        deg_vec_out =  deg_vec - torch.diag(adj_in)   

        return deg_vec_out 

    def compute_laplacian(self,adj_in,deg_vec_out):
        deg_vec_out[deg_vec_out==0] = 1.0
        deg_vec_out = 1/torch.sqrt(deg_vec_out)
        adj_p_i = adj_in + torch.diag(torch.ones(adj_in.size(0)))
        adj_p_i[adj_p_i > 1] = 1
        left_mul = torch.transpose(deg_vec_out * torch.transpose(adj_p_i,0,1),0,1)
        right_mul = left_mul*deg_vec_out
    
        return right_mul


    def compute_node_edge_adj(self,rel_rep,obj_rep,rel_inds_i):
        numer = torch.arange(0, rel_inds_i.size(0), device=rel_inds_i.get_device() if rel_inds_i.is_cuda else 'cpu').long()
        objs_to_outrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_outrels.view(-1)[rel_inds_i[:, 0] * rel_rep.size(0) + numer] = 1
        objs_to_outrels = Variable(objs_to_outrels)
        
        objs_to_inrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_inrels.view(-1)[rel_inds_i[:, 1] * rel_rep.size(0) + numer] = 1
        objs_to_inrels = Variable(objs_to_inrels)

        trans_matrix = objs_to_outrels+objs_to_inrels
        trans_matrix[trans_matrix>1] = 1.0
    
        return trans_matrix
        #return objs_to_outrels,objs_to_inrels 

    def create_adjacency_mat(self,edge_adj,num_edges,is_dir):
        adj_mat = torch.zeros(num_edges,num_edges)
        adj_mat[edge_adj[:,0],edge_adj[:,1]] = 1.0
        if is_dir == False:
            adj_mat[edge_adj[:,1],edge_adj[:,0]] = 1.0  

        return adj_mat

    def propagte_node_edge(self,H1e_i,Hn_i,rel_inds_i,gt_obj_labels):

        self.mp_iter = 3

        He = torch.cat([Hn_i[rel_inds_i[:,0]],H1e_i,Hn_i[rel_inds_i[:,1]]],axis = 1)
        #He = He_i.clone()
        Hn = Hn_i.clone()

        num_nodes = Hn.size(0)
        A_n = self.create_adjacency_mat(rel_inds_i,num_nodes,False)
        deg_vec_out = self.create_deg_matrix(A_n)
        
        A_n  = self.compute_laplacian(A_n,deg_vec_out)

        A_e_edges = self.create_edge_adjacency(rel_inds_i)
        A_e = self.create_adjacency_mat(A_e_edges,rel_inds_i.size(0),False)
        deg_vec_out = self.create_deg_matrix(A_e)
        A_e  = self.compute_laplacian(A_e,deg_vec_out)

        T_mat = self.compute_node_edge_adj(He,Hn,rel_inds_i)
        
        for i in range(self.mp_iter + 1):
            
            if i == 0:
                out_vec = self.pe1(He)
            elif i == 1:
                out_vec = self.pe2(He)
            elif i == 2:
                out_vec = self.pe3(He)
            else:
                out_vec = self.pe4(He)

            
            A_out_n  = torch.transpose(torch.transpose(T_mat,0,1)*out_vec,0,1)
            A_out_n = A_out_n @ torch.transpose(T_mat,0,1)
            A_n = A_n.to(device = A_out_n.get_device())
            D_out_n = A_out_n * A_n
            
            if i == 0:
                feat_update_n = self.wn1(Hn)
            elif i == 1:
                feat_update_n = self.wn2(Hn)
            elif i == 2:
                feat_update_n = self.wn3(Hn)    
            else:
                feat_update_n = self.wn4(Hn)
            
            Hn_out = D_out_n @ feat_update_n
            
            if i == 0:
                out_vec_e = self.pv1(Hn)
            elif i ==1:
                out_vec_e = self.pv2(Hn)
            elif i ==2:
                out_vec_e = self.pv3(Hn)
            else:
                out_vec_e = self.pv3(Hn)
                          

            A_out_e = torch.transpose(T_mat*out_vec_e,0,1)
            A_out_e = A_out_e @ T_mat
            A_e = A_e.to(device = A_out_e.get_device())
            D_out_e = A_out_e * A_e
            
            if i == 0:  
                feat_update_e = self.we1(He)
            elif i == 1:
                feat_update_e = self.we2(He)
            elif i ==2:
                feat_update_e = self.we3(He) 
            else:
                feat_update_e = self.we4(He)          
            #print("feat_update_e:",feat_update_e.size(),"He:",He.size())
            He_out = D_out_e @ feat_update_e
            
            Hn = F.relu(Hn_out)
            He = F.relu(He_out)

        # print("He:",He.shape)
        # print("Hn:",Hn.shape)
        merge_node_feat = F.relu(self.merge_node(torch.cat([Hn,Hn_i],axis = 1)))
        #merge_edge_feat = F.relu(self.merge_edge(torch.cat([He,He_i],axis = 1)))
        # edge_cat1 = torch.cat([Hn_i[rel_inds_i[:,0]],He_i,Hn_i[rel_inds_i[:,1]]],axis = 1)
        edge_cat1 = torch.cat([Hn_i[rel_inds_i[:,0]],H1e_i,Hn_i[rel_inds_i[:,1]]],axis = 1)
        #edge_cat2 = torch.cat([Hn[rel_inds_i[:,0]],He,Hn[rel_inds_i[:,1]]],axis = 1)
        #merge_edge_feat = F.relu(self.merge_edge(torch.cat([edge_cat1,edge_cat2],axis =1)))
        merge_edge_feat = F.relu(self.merge_edge(torch.cat([edge_cat1,He],axis =1)))

        if False: #self.training:
            sub_inds_i =  gt_obj_labels[rel_inds_i[:,0]] 
            obj_inds_i =  gt_obj_labels[rel_inds_i[:,1]]
            kg_mat = np.load('obj_matrix.npy')
            kg_mat = torch.from_numpy(kg_mat)
            weights_out = kg_mat[sub_inds_i,obj_inds_i]
            soft_weights = weights_out/torch.sum(weights_out)

        else:
            soft_weights =   torch.ones(rel_inds_i.size(0))/ rel_inds_i.size(0)

        soft_weights = soft_weights.to(device = rel_inds_i.get_device())
        #print("soft_weights:",soft_weights)
        #exit()
        return merge_node_feat,merge_edge_feat,soft_weights
        
    def message_pass(self, rel_rep, obj_rep, rel_inds):
        """

        :param rel_rep: [num_rel, fc]
        :param obj_rep: [num_obj, fc]
        :param rel_inds: [num_rel, 2] of the valid relationships
        :return: object prediction [num_obj, 151], bbox_prediction [num_obj, 151*4] 
                and rel prediction [num_rel, 51]
        """
        # [num_obj, num_rel] with binary!

       
        numer = torch.arange(0, rel_inds.size(0), device=rel_inds.get_device() if rel_inds.is_cuda else 'cpu').long()

        objs_to_outrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_outrels.view(-1)[rel_inds[:, 0] * rel_rep.size(0) + numer] = 1
        objs_to_outrels = Variable(objs_to_outrels)

        objs_to_inrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_inrels.view(-1)[rel_inds[:, 1] * rel_rep.size(0) + numer] = 1
        objs_to_inrels = Variable(objs_to_inrels)

        hx_rel = Variable(rel_rep.data.new(rel_rep.size(0), self.hidden_dim).zero_(), requires_grad=False)
        hx_obj = Variable(obj_rep.data.new(obj_rep.size(0), self.hidden_dim).zero_(), requires_grad=False)

        vert_factor = [self.node_gru(obj_rep, hx_obj)]
        edge_factor = [self.edge_gru(rel_rep, hx_rel)]

        for i in range(self.mp_iter):
            # compute edge context
            sub_vert = vert_factor[i][rel_inds[:, 0]]
            obj_vert = vert_factor[i][rel_inds[:, 1]]
            weighted_sub = self.sub_vert_w_fc(
                torch.cat((sub_vert, edge_factor[i]), 1)) * sub_vert
            weighted_obj = self.obj_vert_w_fc(
                torch.cat((obj_vert, edge_factor[i]), 1)) * obj_vert

            edge_factor.append(self.edge_gru(weighted_sub + weighted_obj, edge_factor[i]))

            # Compute vertex context
            pre_out = self.out_edge_w_fc(torch.cat((sub_vert, edge_factor[i]), 1)) * \
                      edge_factor[i]
            pre_in = self.in_edge_w_fc(torch.cat((obj_vert, edge_factor[i]), 1)) * edge_factor[
                i]

            vert_ctx = objs_to_outrels @ pre_out + objs_to_inrels @ pre_in
            vert_factor.append(self.node_gru(vert_ctx, vert_factor[i]))

        return vert_factor[-1], edge_factor[-1]


    def predict(self, node_feat, edge_feat, rel_inds, rois, im_sizes):

        # combine edge visual and box features
      
        
        edge_feat = self.union_boxes(edge_feat.view(edge_feat.shape[0], -1, self.pool_sz, self.pool_sz),
                                     rois, rel_inds[:, 1:], im_sizes)
        
        node_feat = self.obj_unary(self.roi_fmap_obj(node_feat.view(node_feat.shape[0], -1)))
        
        edge_feat = F.relu(self.edge_unary(self.roi_fmap(edge_feat)))
        
        node_feat, edge_features = self.message_pass(edge_feat, node_feat, rel_inds[:, 1:3])

        return self.obj_fc(node_feat), self.rel_fc(edge_features)

    
    def get_relind_match_query(self,ref_im_idx,mat1,mat2):
        #### mat2 query matrix
        ### mat1 input matrix queried
        idx_list = []
        ref_im_batch = []
        for rel_ in range(mat2.size(0)):
            q_ = mat2[rel_]
            out = torch.logical_and(mat1[:,0] == q_[0],mat1[:,1] == q_[1]).nonzero(as_tuple = True)[0]                  
            idx_list.append(out)
            ref_im_batch.append(ref_im_idx[out])                            
        return torch.cat(idx_list,axis = 0),torch.cat(ref_im_batch,axis = 0)
                                                                        

          
    def predict_greedy(self, node_feat, edge_feat, rel_inds, gt_obj_labels,gt_rel_labels,rois, im_sizes):

        # combine edge visual and box features
        
        #print("rel_inds___:",rel_inds.size())
        #print("rois___:",rois.size())
        
        edge_feat = self.union_boxes(edge_feat.view(edge_feat.shape[0], -1, self.pool_sz, self.pool_sz),
                                     rois, rel_inds[:, 1:], im_sizes)
        
        node_feat = self.gd_obj_unary(self.roi_fmap_obj(node_feat.view(node_feat.shape[0], -1)))
        edge_feat = F.relu(self.gd_edge_unary(self.roi_fmap(edge_feat)))

        #node_feat, edge_features = self.message_pass_greedy(edge_feat, node_feat, rel_inds,gt_obj_labels,gt_rel_labels)
        node_feat,edge_features,soft_weights = self.propagte_node_edge(edge_feat,node_feat,rel_inds[:,1:3],gt_obj_labels)
        #node_feat = self.message_pass_greedy(edge_feat, node_feat, rel_inds,gt_obj_labels,gt_rel_labels)
        #node_feat_old, edge_features = self.message_pass(edge_feat, node_feat, rel_inds)
        
        return self.gd_obj_fc(node_feat), self.gd_rel_fc(edge_features),soft_weights
        #return self.obj_fc(node_feat), self.rel_fc(edge_features)
   

    def forward(self, batch):
        """
        Forward pass for detection

        Training parameters:
        :param gt_boxes: [num_gt, 4] GT boxes over the batch.
        :param gt_classes: [num_gt, 2] gt boxes where each one is (img_id, class)
        :param gt_rels: [num_gt_rels, 4] gt relationships where each one is (img_id, subj_id, obj_id, class)

        """

        assert len(batch) == 1, ('single GPU is only supported in this code', len(batch))

        x, gt_boxes, gt_classes, gt_rels = batch[0][0], batch[0][3], batch[0][4], batch[0][5]
        with NO_GRAD():  # do not update anything in the detector
            if self.backbone == 'vgg16_old':
                raise NotImplementedError('%s is not supported any more' % self.backbone)
            else:
                result = self.faster_rcnn(x, gt_boxes, gt_classes, gt_rels)
        
        result.fmap = result.fmap.detach()  # do not update the detector

        im_inds = result.im_inds
        boxes = result.rm_box_priors
        #exit()
        if self.training and result.rel_labels is None:
            assert self.mode == 'sgdet'
            result.rel_labels = rel_assignments(im_inds.data, boxes.data, result.rm_obj_labels.data,
                                                gt_boxes.data, gt_classes.data, gt_rels.data,
                                                0, filter_non_overlap=True, num_sample_per_gt=1)

        elif not hasattr(result, 'rel_labels'):
            result.rel_labels = None
        
        # print("rel_inds:",result.rel_labels.size())
        # print("val1:",torch.max(result.rel_labels[:,0]),"val2:","\t",torch.max(result.rel_labels[:,1]),
        # "val3:","\t",torch.max(result.rel_labels[:,2]),"\t","val4:","\t",torch.max(result.rel_labels[:,3]))
        rel_inds = self.get_rel_inds(result.rel_labels if self.training else None, im_inds, boxes)
        result.rel_inds = rel_inds
        # print("rel_inds:",rel_inds.size())
        # print("val1:",torch.max(rel_inds[:,0]),"val2:","\t",torch.max(rel_inds[:,1]),"val3:","\t",torch.max(rel_inds[:,2]))
        # exit()

        rois = torch.cat((im_inds[:, None].float(), boxes), 1)

        result.node_feat, result.edge_feat = self.node_edge_features(result.fmap,
                                                                     rois,
                                                                     rel_inds[:, 1:],
                                                                     im_sizes=result.im_sizes)
        
        result.rm_obj_dists, result.rel_dists,soft_weights = self.predict_greedy(result.node_feat,result.edge_feat,
                                                             rel_inds,result.rm_obj_labels,
                                                             result.rel_labels,rois=rois,im_sizes=result.im_sizes)

        # result.rm_obj_dists, result.rel_dists = self.predict(result.node_feat,
        #                                                      result.edge_feat,
        #                                                      rel_inds,
        #                                                      rois=rois,
        #                                                      im_sizes=result.im_sizes)

        if self.use_bias:

            scores_nz = F.softmax(result.rm_obj_dists, dim=1).data
            scores_nz[:, 0] = 0.0
            _, score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
            result.obj_preds = score_ord[:, 0] + 1

            if self.mode == 'predcls':
                result.obj_preds = gt_classes.data[:, 1]

            freq_pred = self.freq_bias.index_with_labels(torch.stack((
                result.obj_preds[rel_inds[:, 1]],
                result.obj_preds[rel_inds[:, 2]],
            ), 1))
            # tune the weight for freq_bias
            if self.test_bias:
                result.rel_dists = freq_pred
            else:
                result.rel_dists = result.rel_dists + freq_pred
        
        #print("self.training",self.training)

        if self.training:
            result.rois = rois
            return result,soft_weights
        
        
        if self.mode == 'predcls':
            result.obj_scores = result.rm_obj_dists.data.new(gt_classes.shape[0]).fill_(1)
            result.obj_preds = gt_classes.data[:, 1]
        elif self.mode in ['sgcls', 'sgdet']:
            scores_nz = F.softmax(result.rm_obj_dists, dim=1).data
            scores_nz[:, 0] = 0.0  # does not change actually anything
            result.obj_scores, score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
            result.obj_preds = score_ord[:, 0] + 1
            result.obj_scores = result.obj_scores[:,0]
        else:
            raise NotImplementedError(self.mode)

        result.obj_preds = Variable(result.obj_preds)
        result.obj_scores = Variable(result.obj_scores)

        # Boxes will get fixed by filter_dets function.
        if self.backbone != 'vgg16_old':
            bboxes = result.rm_box_priors_org
        else:
            bboxes = result.rm_box_priors

        rel_rep = F.softmax(result.rel_dists, dim=1)

        return filter_dets(bboxes, result.obj_scores,
                           result.obj_preds, rel_inds[:, 1:], rel_rep)
