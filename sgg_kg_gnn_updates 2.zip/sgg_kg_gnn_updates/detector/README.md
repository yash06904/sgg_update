
Based on this tutorial:

https://pytorch.org/tutorials/intermediate/torchvision_tutorial.html