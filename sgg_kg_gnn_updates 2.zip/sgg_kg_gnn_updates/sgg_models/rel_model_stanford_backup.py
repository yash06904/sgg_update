import torch.nn as nn
import torch.nn.parallel
from torch.autograd import Variable
from torch.nn import functional as F
from sgg_models.rel_model_base import RelModelBase
from lib.rel_assignments import rel_assignments
from lib.losses import node_losses, edge_losses #### YM ####
from lib.surgery import filter_dets
from config import NO_GRAD


class RelModelStanford(RelModelBase):

    def __init__(self,
                 train_data,
                 hidden_dim=512,
                 mp_iter=3,
                 **kwargs):
        """
        Message Passing Model from Scene Graph Generation by Iterative Message Passing (https://arxiv.org/abs/1701.02426)
        :param classes: Object classes
        :param rel_classes: Relationship classes. None if were not using rel mode
        """
        super(RelModelStanford, self).__init__(train_data, **kwargs)

        print(self.mode, self.backbone, self.RELS_PER_IMG, self.use_bias, self.test_bias, self.require_overlap)

        self.hidden_dim = hidden_dim

        # self.rel_fc = nn.Linear(hidden_dim, self.num_rels)
        # self.obj_fc = nn.Linear(hidden_dim, self.num_classes)

        self.gd_rel_fc = nn.Linear(2*hidden_dim, self.num_rels)
        self.gd_obj_fc = nn.Linear(2*hidden_dim, self.num_classes)

        # self.obj_unary = nn.Linear(self.obj_dim, hidden_dim)
        # self.edge_unary = nn.Linear(self.obj_dim, hidden_dim)
        
        self.gd_obj_unary = nn.Linear(self.obj_dim, hidden_dim)
        self.gd_edge_unary = nn.Linear(self.obj_dim, hidden_dim)


        # self.edge_gru = nn.GRUCell(input_size=hidden_dim, hidden_size=hidden_dim)
        # self.node_gru = nn.GRUCell(input_size=hidden_dim, hidden_size=hidden_dim) 

        self.gd_edge_gru = nn.GRUCell(input_size=hidden_dim, hidden_size=hidden_dim)
        self.gd_node_gru = nn.GRUCell(input_size=hidden_dim, hidden_size=hidden_dim)

        self.mp_iter = mp_iter

        # self.sub_vert_w_fc = nn.Sequential(nn.Linear(hidden_dim*2, 1), nn.Sigmoid())
        # self.obj_vert_w_fc = nn.Sequential(nn.Linear(hidden_dim*2, 1), nn.Sigmoid())
        # self.out_edge_w_fc = nn.Sequential(nn.Linear(hidden_dim*2, 1), nn.Sigmoid())
        # self.in_edge_w_fc = nn.Sequential(nn.Linear(hidden_dim*2, 1), nn.Sigmoid())

        #### YM ####

        self.compress_edge = nn.Linear(3*hidden_dim,hidden_dim)
        
        #### YM ####
        self.ob_mat = torch.ones(151,151)
        self.rel_mat = 0.01*torch.ones(151,151,51)


    def message_pass(self, rel_rep, obj_rep, rel_inds):
        """

        :param rel_rep: [num_rel, fc]
        :param obj_rep: [num_obj, fc]
        :param rel_inds: [num_rel, 2] of the valid relationships
        :return: object prediction [num_obj, 151], bbox_prediction [num_obj, 151*4] 
                and rel prediction [num_rel, 51]
        """
        # [num_obj, num_rel] with binary!
        numer = torch.arange(0, rel_inds.size(0), device=rel_inds.get_device() if rel_inds.is_cuda else 'cpu').long()

        objs_to_outrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_outrels.view(-1)[rel_inds[:, 0] * rel_rep.size(0) + numer] = 1
        objs_to_outrels = Variable(objs_to_outrels)

        objs_to_inrels = rel_rep.data.new(obj_rep.size(0), rel_rep.size(0)).zero_()
        objs_to_inrels.view(-1)[rel_inds[:, 1] * rel_rep.size(0) + numer] = 1
        objs_to_inrels = Variable(objs_to_inrels)

        hx_rel = Variable(rel_rep.data.new(rel_rep.size(0), self.hidden_dim).zero_(), requires_grad=False)
        hx_obj = Variable(obj_rep.data.new(obj_rep.size(0), self.hidden_dim).zero_(), requires_grad=False)

        vert_factor = [self.node_gru(obj_rep, hx_obj)]
        edge_factor = [self.edge_gru(rel_rep, hx_rel)]

        for i in range(self.mp_iter):
            # compute edge context
            sub_vert = vert_factor[i][rel_inds[:, 0]]
            obj_vert = vert_factor[i][rel_inds[:, 1]]
            weighted_sub = self.sub_vert_w_fc(
                torch.cat((sub_vert, edge_factor[i]), 1)) * sub_vert
            weighted_obj = self.obj_vert_w_fc(
                torch.cat((obj_vert, edge_factor[i]), 1)) * obj_vert

            edge_factor.append(self.edge_gru(weighted_sub + weighted_obj, edge_factor[i]))

            # Compute vertex context
            pre_out = self.out_edge_w_fc(torch.cat((sub_vert, edge_factor[i]), 1)) * \
                      edge_factor[i]
            pre_in = self.in_edge_w_fc(torch.cat((obj_vert, edge_factor[i]), 1)) * edge_factor[
                i]

            vert_ctx = objs_to_outrels @ pre_out + objs_to_inrels @ pre_in
            vert_factor.append(self.node_gru(vert_ctx, vert_factor[i]))

        return vert_factor[-1], edge_factor[-1]


    def predict(self, node_feat, edge_feat, rel_inds, rois, im_sizes):

        # combine edge visual and box features
      
        
        edge_feat = self.union_boxes(edge_feat.view(edge_feat.shape[0], -1, self.pool_sz, self.pool_sz),
                                     rois, rel_inds[:, 1:], im_sizes)
        
        node_feat = self.obj_unary(self.roi_fmap_obj(node_feat.view(node_feat.shape[0], -1)))
        
        edge_feat = F.relu(self.edge_unary(self.roi_fmap(edge_feat)))
        
        node_feat, edge_features = self.message_pass(edge_feat, node_feat, rel_inds[:, 1:3])

        return self.obj_fc(node_feat), self.rel_fc(edge_features)

    def aggregate_obj_messages(self,obj_rep_i,rel_imgs_mat_i,f_bb_idx_i,num_roi,kg_mat_vec):
        # YM Debug

        #print("obj_rep_i:",obj_rep_i.shape)
        #print("rel_imgs_mat_i:",rel_imgs_mat_i.shape)
        #print("f_bb_idx_i:",f_bb_idx_i,"\t","num_roi:",num_roi)
        #print("kg_mat_vec:",kg_mat_vec)
        uniq_nodes_s = torch.unique(rel_imgs_mat_i[:,0])
        uniq_nodes_o = rel_imgs_mat_i[:,1]
        kg_mat_vec = kg_mat_vec.to(device=obj_rep_i.get_device())
        obj_agg = []

        for i in range(uniq_nodes_s.size(0)):
            id_x = uniq_nodes_s[i]
            target_idx = (uniq_nodes_s==id_x).nonzero()
            #print("target_idx:",target_idx.shape)
            tmp_rep_kg = obj_rep_i.data.new(target_idx.size(0),obj_rep_i.size(1)).zero_()
            #print("target_idx:",target_idx)

            obj_rep_t = torch.transpose(obj_rep_i[target_idx],0,1).to(device = obj_rep_i.get_device()) 
            obj_rep_t_kg = obj_rep_t * kg_mat_vec[target_idx]
            obj_rep_t_kg =  torch.transpose(obj_rep_t_kg,0,1)
            
            obj_agg.append(obj_rep_i[id_x]+torch.mean(obj_rep_t_kg,axis = 0))

        obj_agg_img = torch.cat(obj_agg,axis = 0)

        return obj_agg_img     
        
        # obj_rep_ = obj_rep_i.clone()
        # rel_imgs_mat_ = rel_imgs_mat_i.clone()
        
        
        # f_bb_idx_ = f_bb_idx_i.copy()
        # #print("obj_rep_[f_bb_idx_]:",obj_rep_[f_bb_idx_].shape)
        # kg_mat_vec = kg_mat_vec.to(device=obj_rep_.get_device())
        # # print("kg_mat_vec:",kg_mat_vec.shape)
        # # print("kg_mat_vec:",kg_mat_vec)
        # # print("f_bb_idx_:",len(f_bb_idx_))
        
        # #obj_rep_[f_bb_idx_] = torch.transpose((torch.transpose(obj_rep_[f_bb_idx_],0,1)*kg_mat_vec),0,1)
        # adj_mat = obj_rep_i.data.new(num_roi,num_roi ).zero_()

        # adj_mat[rel_imgs_mat_[:,0],rel_imgs_mat_[:,1]] = kg_mat_vec
        # adj_mat = Variable(adj_mat)
        
        # #print("adj_mat:",torch.nonzero(adj_mat,as_tuple=True))
        
        # X = adj_mat @ obj_rep_i
        # out_t = obj_rep_i[f_bb_idx_i] + X[f_bb_idx_i] 
        
        # #print("out_t:",out_t)
        # return out_t


    def aggregate_messages_rel(self,rel_rep_i,rel_imgs_mat_i,ref_im_batch_i,num_obj_batch_i,kg_rel_wt_i):
        
        # active_edges = rel_rep_i.data.new(len(rel_rep_i),2).zero_()
        # active_edges[:,0] = torch.tensor(ref_im_batch_i).to(device=rel_rep_i.get_device())
        # active_edges[:,1] = torch.arange(len(rel_rep_i))
        
        # adj_mat = rel_rep_i.data.new(len(rel_rep_i),len(rel_rep_i)).zero_()
        # kg_rel_wt_i = kg_rel_wt_i.to(device=rel_rep_i.get_device())
        
        # print("rel_imgs_mat_i:",rel_imgs_mat_i)
        # print("rel_rep_i:",rel_rep_i.shape)
        # print("adj_mat:",adj_mat.shape)
        # print("kg_rel_wt_i:",kg_rel_wt_i.shape)
        # print("active_edges:",active_edges)

        # print("active_edges:",active_edges.shape,"max:",torch.max(active_edges[:,0]),"max:",torch.max(active_edges[:,1]))
        # print("active_edges:",active_edges.shape,"min:",torch.min(active_edges[:,0]),"min:",torch.min(active_edges[:,1]))
        # adj_mat[active_edges[:,0].to(torch.long),active_edges[:,1].to(torch.long)] = kg_rel_wt_i
        
        # rel_agg = adj_mat @ rel_rep_i
        # rel_agg_img = rel_agg[active_edges[:,0].unique().to(torch.long)]

        ### Alternate code ####

        rel_agg = []
        uniq_nodes_s = torch.unique(rel_imgs_mat_i[:,0])
        uniq_nodes_o = rel_imgs_mat_i[:,1]
        kg_rel_wt_i = kg_rel_wt_i.to(device=rel_rep_i.get_device())
        for i in range(uniq_nodes_s.size(0)):
            id_x = uniq_nodes_s[i]
            target_idx = (uniq_nodes_s==id_x).nonzero()
            #print("target_idx:",target_idx.shape)
            tmp_rep_kg = rel_rep_i.data.new(target_idx.size(0),rel_rep_i.size(1)).zero_()
            #print("target_idx:",target_idx)

            rel_rep_t = torch.transpose(rel_rep_i[target_idx],0,1).to(device = rel_rep_i.get_device()) 
            rel_rep_t_kg = rel_rep_t * kg_rel_wt_i[target_idx]
            rel_rep_t_kg =  torch.transpose(rel_rep_t_kg,0,1)
            
            rel_agg.append(torch.mean(rel_rep_t_kg,axis = 0))

        rel_agg_img = torch.cat(rel_agg,axis = 0)

        return rel_agg_img 



    def get_relind_match_query(self,ref_im_idx,mat1,mat2):
        #### mat2 query matrix
        ### mat1 input matrix queried
        idx_list = []
        ref_im_batch = []
        for rel_ in range(mat2.size(0)):
            q_ = mat2[rel_]
            out = torch.logical_and(mat1[:,0] == q_[0],mat1[:,1] == q_[1]).nonzero(as_tuple = True)[0]                  
            idx_list.append(out)
            ref_im_batch.append(ref_im_idx[out])                            
        return torch.cat(idx_list,axis = 0),torch.cat(ref_im_batch,axis = 0)

    def message_pass_greedy(self, rel_rep, obj_rep, rel_inds,gt_obj,gt_rel):
        """

        :param rel_rep: [num_rel, fc]
        :param obj_rep: [num_obj, fc]
        :param rel_inds: [num_rel, 2] of the valid relationships
        :return: object prediction [num_obj, 151], bbox_prediction [num_obj, 151*4] 
                and rel prediction [num_rel, 51]
        """
        # [num_obj, num_rel] with binary!
        ##### find max bounding boxes ###
        #print("obj_rep:",obj_rep.shape)
          
        # print("rel_rep:",rel_rep.shape)
        # print("obj_rep:",obj_rep.shape)
        # print("rel_inds:",rel_inds.shape)
        # if self.training == False:
        #     print("rel_inds:",rel_inds)  
        #     exit()
        num_bb = torch.max(torch.bincount(self.obj_im_ind.to(int)))
        #print("num_bb:",num_bb)

        updated_obj_rep = obj_rep.data.new(obj_rep.size(0),2*self.hidden_dim).zero_()
        updated_rel_rep = rel_rep.data.new(rel_rep.size(0),2*self.hidden_dim).zero_()

        rel_bb_ubb_cat = rel_rep.data.new(rel_rep.size(0),3*self.hidden_dim).zero_()
        rel_bb_ubb_cat = torch.cat([obj_rep[rel_inds[:,0]],rel_rep,obj_rep[rel_inds[:,1]]],axis = 1)
        #rel_bb_ubb_cat = rel_rep.clone()
        
        obj_img_list = []
        key_vec = self.offset_dict[:,0]
        val_vec = self.offset_dict[:,1]

        num_img_per_batch = key_vec.size(0)
        for i in range(key_vec.size(0)):
            bb_feat_list = []
            s = int(val_vec[i])
            if i == key_vec.size(0)-1:
                e = obj_rep.size(0)
            else:
                e = int(val_vec[i+1])

            for j in range(s,e):
                #print("s:",s,"\t","e:",e)          
                bb_feat_list.append(j)                
            #print("bb_id:",bb_feat_list) 
            obj_img_list.append(bb_feat_list)

        
        rel_img_list = []
        rel_bin_count = torch.bincount(self.rel_im_ind.to(int))    
        num_obj_batch = sum(torch.bincount(self.obj_im_ind.to(int)))
        
        uniq_im_id  = self.rel_im_ind.unique()
        sum_vec = []

        for i in range (uniq_im_id.size(0)):
            
            per_im_rel = rel_inds[self.rel_im_ind==uniq_im_id[i]][:,1:]
            rel_img_list.append(per_im_rel)
            sum_vec.append(per_im_rel.size(0))
            #print("per_im_rel:",per_im_rel)

        bb_idx_img = []
        rel_img_idx = []
        img_ids_per_box = []
        bb_decoded_ph = -1*torch.ones(num_obj_batch)
        bb_decoded_ph = bb_decoded_ph.to(float)
        bb_decoded_ph = bb_decoded_ph.to(device='cuda') #### refine this 

        for bb_idx in range(num_bb):                   #### loop over the bounding boxes
            first_bb_idx = []
            rel_mat_img = []
            im_id_bb = []
            #print("bb_idx:",bb_idx)              
            for im_idx in range(len(rel_img_list)):    #### loop over the batch of images
                 
                if bb_idx < len(obj_img_list[im_idx]):
                    first_bb_idx.append(obj_img_list[im_idx][bb_idx])
                    im_id_bb.append(im_idx)

                if(bb_idx > 0 and (bb_idx < len(obj_img_list[im_idx]))):
                    #### extract edges related to previous bounding boxes
                    rel_mat_ = rel_img_list[im_idx]
                    o_id = obj_img_list[im_idx][bb_idx]
                    #rel_mat_ = rel_mat[rel_mat[:,0] > rel_mat[:,1]]
                    rel_mat_ = rel_mat_[rel_mat_[:,0] == o_id]                     
                    rel_mat_img.append(rel_mat_)
             
            bb_idx_img.append(first_bb_idx)
            rel_img_idx.append(rel_mat_img)
            img_ids_per_box.append(im_id_bb)
         
        ###### process the above data structures with message passing #######
        hx_obj = Variable(obj_rep.data.new(num_img_per_batch, self.hidden_dim).zero_(), requires_grad=False)
        hx_rel = Variable(rel_rep.data.new(num_img_per_batch, self.hidden_dim).zero_(), requires_grad=False) 
        #obj_pred_list = torch.ones()

        for bb_idx in range(num_bb):
            f_bb_idx = bb_idx_img[bb_idx]
            bb_batch = obj_rep[f_bb_idx]
            img_id_in_bbid = img_ids_per_box[bb_idx]
            hx_obj_ = hx_obj[img_id_in_bbid]
            obj_rep_tmp = torch.cat([bb_batch,hx_obj_],axis = 1)
            updated_obj_rep[f_bb_idx] = obj_rep_tmp
            node_obj_dist = self.gd_obj_fc(obj_rep_tmp)
            
            if self.training:
                gt_obj_bb = gt_obj[f_bb_idx]
                losses = node_losses(node_obj_dist,gt_obj_bb)
                obj_preds = gt_obj_bb
            else:
                scores_nz = F.softmax(node_obj_dist, dim=1).data
                # scores_nz[:, 0] = 0.0  # does not change actually anything
                # obj_scores, score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
                obj_scores, score_ord = scores_nz[:, 0:].sort(dim=1, descending=True)
                obj_preds = score_ord[:, 0]
                #print("obj_preds:",obj_preds)
                #print("score_ord:",score_ord[:,0]+1)  
            
            #print("obj_preds:",obj_preds)
            bb_decoded_ph = bb_decoded_ph.to(obj_preds.dtype)
            
            bb_decoded_ph[f_bb_idx] = obj_preds
            #print("self.bb_decoded_ph:",bb_decoded_ph)

            if bb_idx > 0:       
                rel_imgs_mat = torch.cat(rel_img_idx[bb_idx],axis = 0)                
                rel_mat_for_obd = rel_imgs_mat[rel_imgs_mat[:,0] > rel_imgs_mat[:,1]]
                sub_idx = bb_decoded_ph[rel_mat_for_obd[:,0]]
                ob_idx  = bb_decoded_ph[rel_mat_for_obd[:,1]]
                
                check_sub_idx = (sub_idx == -1).nonzero(as_tuple =True)[0]
                check_ob_idx = (ob_idx == -1).nonzero(as_tuple =True)[0]
                
                neg_len = len(check_sub_idx) + len(check_ob_idx)

                if (neg_len > 0):
                    print("Trying to access un detected object, this should not happen, degug error in code")
                    exit()  

                kg_weights = self.ob_mat[sub_idx,ob_idx]
                
                ob_agg = self.aggregate_obj_messages(obj_rep,rel_mat_for_obd,f_bb_idx,num_obj_batch,kg_weights)
                
                hx_obj[img_id_in_bbid] = self.gd_node_gru(ob_agg,hx_obj[img_id_in_bbid])
               
                rel_ind_mat_bb,ref_im_batch = self.get_relind_match_query(rel_inds[:,0],rel_inds[:,1:],rel_imgs_mat)

                compress_edge_feat = self.compress_edge(rel_bb_ubb_cat[rel_ind_mat_bb])

                cmp_rel_rep_mat = torch.cat([compress_edge_feat,hx_rel[ref_im_batch]],axis =1)
              
                updated_rel_rep[ref_im_batch] = cmp_rel_rep_mat
                
                edge_rel_dist = self.gd_rel_fc(cmp_rel_rep_mat)


                if self.training:   
                    gt_rel_bb = gt_rel[rel_ind_mat_bb]                                 
                    edge_loss_, edges_fg_, edges_bg_ = edge_losses(edge_rel_dist,   # predicted edge labels (predicates)
                                           gt_rel_bb[:,-1],   # ground truth edge labels (predicates)
                                           'baseline',
                                           return_idx=True,
                                           loss_weights=(1.0, 1.0, 1.0))
                    rel_preds = gt_rel_bb[:,-1]
                else:
                    scores_nz = F.softmax(edge_rel_dist, dim=1).data
                    #scores_nz[:, 0] = 0.0  # does not change actually anything
                    #rel_scores, rel_score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
                    rel_scores, rel_score_ord = scores_nz[:, 0:].sort(dim=1, descending=True)
                    rel_preds = rel_score_ord[:, 0]
                    #rel_preds = rel_score_ord[:, 0] + 1
                
                #print("ref_im_batch.unique():",ref_im_batch.unique())
                

                kg_rel_weights = self.rel_mat[bb_decoded_ph[rel_imgs_mat[:,0]],bb_decoded_ph[rel_imgs_mat[:,1]],rel_preds]
                # print("kg_rel_weights:",kg_rel_weights.shape)     
                ######## relationship updates correspoinding to bb ######                
                rel_agg = self.aggregate_messages_rel(rel_bb_ubb_cat[rel_ind_mat_bb],rel_imgs_mat,ref_im_batch,num_obj_batch,kg_rel_weights)
                #ref_im_batch_uq = torch.cat(ref_im_batch,axis = 0)
                
                ref_im_batch_uq = ref_im_batch.unique()
                ref_im_batch_uq = ref_im_batch_uq.to(torch.long)
                agg_input_h = self.compress_edge(rel_agg)
                #print("ref_im_batch_uq:",ref_im_batch_uq)
                # print("agg_input_h:",agg_input_h.shape)
                # print("ref_im_batch_uq:",ref_im_batch_uq)
                hx_rel[ref_im_batch_uq] = self.gd_edge_gru(agg_input_h,hx_rel[ref_im_batch_uq])

        
        return updated_obj_rep,updated_rel_rep                                                                          

          
    def predict_greedy(self, node_feat, edge_feat, rel_inds, gt_obj_labels,gt_rel_labels,rois, im_sizes):

        # combine edge visual and box features
        
        #print("rel_inds___:",rel_inds.size())
        #print("rois___:",rois.size())
        
        edge_feat = self.union_boxes(edge_feat.view(edge_feat.shape[0], -1, self.pool_sz, self.pool_sz),
                                     rois, rel_inds[:, 1:], im_sizes)
        
        node_feat = self.gd_obj_unary(self.roi_fmap_obj(node_feat.view(node_feat.shape[0], -1)))
        
        edge_feat = F.relu(self.gd_edge_unary(self.roi_fmap(edge_feat)))
        
        node_feat, edge_features = self.message_pass_greedy(edge_feat, node_feat, rel_inds,gt_obj_labels,gt_rel_labels)
        
        return self.gd_obj_fc(node_feat), self.gd_rel_fc(edge_features)
   

    def forward(self, batch):
        """
        Forward pass for detection

        Training parameters:
        :param gt_boxes: [num_gt, 4] GT boxes over the batch.
        :param gt_classes: [num_gt, 2] gt boxes where each one is (img_id, class)
        :param gt_rels: [num_gt_rels, 4] gt relationships where each one is (img_id, subj_id, obj_id, class)

        """

        assert len(batch) == 1, ('single GPU is only supported in this code', len(batch))

        x, gt_boxes, gt_classes, gt_rels = batch[0][0], batch[0][3], batch[0][4], batch[0][5]
        with NO_GRAD():  # do not update anything in the detector
            if self.backbone == 'vgg16_old':
                raise NotImplementedError('%s is not supported any more' % self.backbone)
            else:
                result = self.faster_rcnn(x, gt_boxes, gt_classes, gt_rels)
        
        result.fmap = result.fmap.detach()  # do not update the detector

        im_inds = result.im_inds
        boxes = result.rm_box_priors
        #exit()
        if self.training and result.rel_labels is None:
            assert self.mode == 'sgdet'
            result.rel_labels = rel_assignments(im_inds.data, boxes.data, result.rm_obj_labels.data,
                                                gt_boxes.data, gt_classes.data, gt_rels.data,
                                                0, filter_non_overlap=True, num_sample_per_gt=1)

        elif not hasattr(result, 'rel_labels'):
            result.rel_labels = None
        
        # print("rel_inds:",result.rel_labels.size())
        # print("val1:",torch.max(result.rel_labels[:,0]),"val2:","\t",torch.max(result.rel_labels[:,1]),
        # "val3:","\t",torch.max(result.rel_labels[:,2]),"\t","val4:","\t",torch.max(result.rel_labels[:,3]))
        rel_inds = self.get_rel_inds(result.rel_labels if self.training else None, im_inds, boxes)
        result.rel_inds = rel_inds
        # print("rel_inds:",rel_inds.size())
        # print("val1:",torch.max(rel_inds[:,0]),"val2:","\t",torch.max(rel_inds[:,1]),"val3:","\t",torch.max(rel_inds[:,2]))
        # exit()

        rois = torch.cat((im_inds[:, None].float(), boxes), 1)

        result.node_feat, result.edge_feat = self.node_edge_features(result.fmap,
                                                                     rois,
                                                                     rel_inds[:, 1:],
                                                                     im_sizes=result.im_sizes)
        
        result.rm_obj_dists, result.rel_dists = self.predict_greedy(result.node_feat,result.edge_feat,
                                                             rel_inds,result.rm_obj_labels,
                                                             result.rel_labels,rois=rois,im_sizes=result.im_sizes)

        # result.rm_obj_dists, result.rel_dists = self.predict(result.node_feat,
        #                                                      result.edge_feat,
        #                                                      rel_inds,
        #                                                      rois=rois,
        #                                                      im_sizes=result.im_sizes)

        if self.use_bias:

            scores_nz = F.softmax(result.rm_obj_dists, dim=1).data
            scores_nz[:, 0] = 0.0
            _, score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
            result.obj_preds = score_ord[:, 0] + 1

            if self.mode == 'predcls':
                result.obj_preds = gt_classes.data[:, 1]

            freq_pred = self.freq_bias.index_with_labels(torch.stack((
                result.obj_preds[rel_inds[:, 1]],
                result.obj_preds[rel_inds[:, 2]],
            ), 1))
            # tune the weight for freq_bias
            if self.test_bias:
                result.rel_dists = freq_pred
            else:
                result.rel_dists = result.rel_dists + freq_pred
        
        #print("self.training",self.training)

        if self.training:
            result.rois = rois
            return result
        
        
        if self.mode == 'predcls':
            result.obj_scores = result.rm_obj_dists.data.new(gt_classes.shape[0]).fill_(1)
            result.obj_preds = gt_classes.data[:, 1]
        elif self.mode in ['sgcls', 'sgdet']:
            scores_nz = F.softmax(result.rm_obj_dists, dim=1).data
            scores_nz[:, 0] = 0.0  # does not change actually anything
            result.obj_scores, score_ord = scores_nz[:, 1:].sort(dim=1, descending=True)
            result.obj_preds = score_ord[:, 0] + 1
            result.obj_scores = result.obj_scores[:,0]
        else:
            raise NotImplementedError(self.mode)

        result.obj_preds = Variable(result.obj_preds)
        result.obj_scores = Variable(result.obj_scores)

        # Boxes will get fixed by filter_dets function.
        if self.backbone != 'vgg16_old':
            bboxes = result.rm_box_priors_org
        else:
            bboxes = result.rm_box_priors

        rel_rep = F.softmax(result.rel_dists, dim=1)

        return filter_dets(bboxes, result.obj_scores,
                           result.obj_preds, rel_inds[:, 1:], rel_rep)
